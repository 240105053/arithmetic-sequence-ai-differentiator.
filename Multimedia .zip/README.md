# Sequence Studio — AI Math Differentiator

A small web app for differentiated practice with **arithmetic sequences**. Learners choose Foundation, Standard, or Advanced and receive an AI-generated task, a hint, a worked solution, and feedback on their answer.

## Stack
- HTML, CSS, and browser JavaScript
- Vercel serverless function (`api/generate.js`)
- OpenAI Responses API

## Run and deploy
1. Create a GitHub repository and upload these files.
2. Import the repository into Vercel.
3. In **Vercel → Project → Settings → Environment Variables**, add:
   - `OPENAI_API_KEY` = your private API key
   - `OPENAI_MODEL` = `gpt-4.1-mini` (optional)
4. Redeploy after adding the environment variables.
5. Open the deployed URL and test all three levels.

The API key must remain in the server environment. **Never put it in `app.js`, `index.html`, or any public repository.**

## Local development
Use the Vercel CLI:
```bash
npm install -g vercel
vercel dev
```
Set `OPENAI_API_KEY` in your local environment before running `vercel dev`. Do not commit `.env`.

## Differentiation design
- **Foundation:** smaller values, explicit identification of the first term/common difference/index, guided steps, direct hints.
- **Standard:** curriculum-level task where learners select the appropriate formula and explain their reasoning.
- **Advanced:** linked, multi-step or applied challenge, for example inferring missing sequence information before calculating a later term or sum.

The backend sends the selected level's instructions to the AI model. It requests a consistent JSON shape containing the question, hint, worked solution, expected answer, and checking notes. The app separately requests hints, solutions, and answer feedback.

## Academic integrity and validation
This project is a starter implementation. Read and adapt the code and prompts so you can explain every part in your own words. Before submission, test multiple generated tasks at every level, verify the arithmetic manually, and record any AI errors and improvements in your report. An AI-generated solution should not be treated as automatically correct.
