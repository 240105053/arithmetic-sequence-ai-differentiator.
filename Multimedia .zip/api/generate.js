const LEVEL_GUIDANCE = {
  foundation: `FOUNDATION: use friendly, plain language; choose small integer values; break the task into short guided steps; include a direct hint that reminds the learner to identify a1, d, and n. Avoid unnecessary context.`,
  standard: `STANDARD: use a typical secondary-school arithmetic-sequence problem; expect the learner to choose the formula and show a concise sequence of reasoning steps. Do not reveal the answer in the question.`,
  advanced: `ADVANCED: use a multi-step challenge or realistic application; require reasoning with at least two linked steps, such as finding unknown parameters and then a later term or sum. Keep the mathematics appropriate for arithmetic sequences.`
};

const schemaInstructions = `Topic: arithmetic sequences (arithmetic progressions).
Core facts: a_n = a_1 + (n-1)d; d = a_(n+1)-a_n; S_n = n(a_1+a_n)/2 = n[2a_1+(n-1)d]/2.
Create mathematically valid, self-contained tasks. Check every calculation before responding. Use plain text and Unicode math symbols if helpful.
Return ONLY valid JSON with this shape:
{"task":{"context":"short context or empty string","question":"the learner-facing question","hint":"one level-appropriate hint, not the full answer","solution":"correct step-by-step solution","answer":"the exact expected final answer as a string","check_note":"what a correct response should contain"}}
Do not include Markdown fences or any text outside JSON.`;

function extractOutputText(data) {
  if (data.output_text) return data.output_text;
  const parts = [];
  for (const item of (data.output || [])) {
    for (const content of (item.content || [])) {
      if (content.type === "output_text" && content.text) parts.push(content.text);
    }
  }
  return parts.join("\n");
}

async function askModel(prompt) {
  const key = process.env.OPENAI_API_KEY;
  if (!key) throw new Error("OPENAI_API_KEY is not set in the deployment environment.");
  const response = await fetch("https://api.openai.com/v1/responses", {
    method: "POST",
    headers: { "Content-Type": "application/json", "Authorization": `Bearer ${key}` },
    body: JSON.stringify({
      model: process.env.OPENAI_MODEL || "gpt-4.1-mini",
      input: prompt
    })
  });
  const data = await response.json();
  if (!response.ok) throw new Error(data.error?.message || "AI provider request failed.");
  return extractOutputText(data);
}

function parseJson(text) {
  const cleaned = text.trim().replace(/^```(?:json)?\s*/i, "").replace(/\s*```$/, "");
  return JSON.parse(cleaned);
}

module.exports = async function handler(req, res) {
  if (req.method !== "POST") return res.status(405).json({ error: "Use POST for this endpoint." });
  try {
    const { action, level, task, answer } = req.body || {};
    if (!LEVEL_GUIDANCE[level]) return res.status(400).json({ error: "Choose a valid learning level." });

    if (action === "generate") {
      const prompt = `${schemaInstructions}\nLearner level instructions: ${LEVEL_GUIDANCE[level]}\nGenerate one fresh task.`;
      const parsed = parseJson(await askModel(prompt));
      if (!parsed.task?.question || !parsed.task?.answer || !parsed.task?.solution) {
        throw new Error("The AI response did not contain all required task fields. Please try again.");
      }
      return res.status(200).json(parsed);
    }

    if (!task || !task.question) return res.status(400).json({ error: "Generate a task first." });

    if (action === "hint") {
      const prompt = `You are a patient mathematics tutor. Level: ${level}. ${LEVEL_GUIDANCE[level]}\nTask: ${task.question}\nGive one useful hint that supports the next step but does not reveal the final answer. Keep it under 70 words.`;
      return res.status(200).json({ hint: (await askModel(prompt)).trim() });
    }
    if (action === "solution") {
      const prompt = `You are a careful mathematics teacher. Level: ${level}. ${LEVEL_GUIDANCE[level]}\nSolve this arithmetic-sequence task correctly and explain each calculation at the learner's level. Task: ${task.question}\nKnown reference answer: ${task.answer}\nReturn only the worked solution, in plain text.`;
      return res.status(200).json({ solution: (await askModel(prompt)).trim() });
    }
    if (action === "check") {
      const prompt = `You are a supportive arithmetic-sequence tutor. Level: ${level}. Task: ${task.question}\nExpected answer: ${task.answer}\nLearner answer: ${String(answer || "").slice(0, 500)}\nCompare the learner's answer with the expected answer, allowing mathematically equivalent formats. Give concise feedback, say whether it is correct, and if incorrect give one next-step hint without simply dumping the full solution. If the answer is ambiguous, explain what needs clarification.`;
      return res.status(200).json({ feedback: (await askModel(prompt)).trim() });
    }
    return res.status(400).json({ error: "Unknown action." });
  } catch (error) {
    console.error("AI endpoint error:", error);
    return res.status(500).json({ error: error.message || "Unexpected server error." });
  }
};
