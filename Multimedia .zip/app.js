const levelButtons = [...document.querySelectorAll(".level-card")];
const generateBtn = document.querySelector("#generateBtn");
const statusBox = document.querySelector("#status");
const taskContent = document.querySelector("#taskContent");
const levelPill = document.querySelector("#levelPill");
const contextEl = document.querySelector("#context");
const questionEl = document.querySelector("#question");
const answerInput = document.querySelector("#answerInput");
const feedback = document.querySelector("#feedback");
const hintBox = document.querySelector("#hintBox");
const hintText = document.querySelector("#hintText");
const solutionBox = document.querySelector("#solutionBox");
const solutionText = document.querySelector("#solutionText");

let selectedLevel = "foundation";
let currentTask = null;

const labels = { foundation: "FOUNDATION", standard: "STANDARD", advanced: "ADVANCED" };

levelButtons.forEach((button) => {
  button.addEventListener("click", () => {
    selectedLevel = button.dataset.level;
    levelButtons.forEach((b) => b.classList.toggle("selected", b === button));
    levelPill.textContent = labels[selectedLevel];
  });
});

function showStatus(message) {
  statusBox.textContent = message;
  statusBox.classList.remove("hidden");
  taskContent.classList.add("hidden");
}
function showTask(task) {
  currentTask = task;
  statusBox.classList.add("hidden");
  taskContent.classList.remove("hidden");
  contextEl.textContent = task.context || "";
  questionEl.textContent = task.question;
  answerInput.value = "";
  feedback.classList.add("hidden");
  hintBox.classList.add("hidden");
  solutionBox.classList.add("hidden");
  hintText.textContent = task.hint;
  solutionText.textContent = task.solution;
}
async function callAI(action, extra = {}) {
  const response = await fetch("/api/generate", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ action, level: selectedLevel, task: currentTask, ...extra })
  });
  const data = await response.json();
  if (!response.ok) throw new Error(data.error || "The request failed.");
  return data;
}
generateBtn.addEventListener("click", async () => {
  generateBtn.disabled = true;
  generateBtn.querySelector("span").textContent = "Creating task…";
  showStatus("Building a task for your selected level. This may take a few seconds.");
  levelPill.textContent = labels[selectedLevel];
  try {
    const data = await callAI("generate");
    showTask(data.task);
  } catch (error) {
    showStatus(`${error.message} Check that OPENAI_API_KEY is configured on the deployed server, then try again.`);
  } finally {
    generateBtn.disabled = false;
    generateBtn.querySelector("span").textContent = "Generate my task";
  }
});

document.querySelector("#hintBtn").addEventListener("click", async () => {
  if (!currentTask) return;
  hintBox.classList.remove("hidden");
  hintText.textContent = "Preparing a level-appropriate hint…";
  try {
    const data = await callAI("hint");
    hintText.textContent = data.hint;
  } catch (error) {
    hintText.textContent = currentTask.hint || error.message;
  }
});
document.querySelector("#solutionBtn").addEventListener("click", async () => {
  if (!currentTask) return;
  solutionBox.classList.remove("hidden");
  solutionText.textContent = "Preparing the worked solution…";
  try {
    const data = await callAI("solution");
    solutionText.textContent = data.solution;
  } catch (error) {
    solutionText.textContent = currentTask.solution || error.message;
  }
});
document.querySelector("#checkBtn").addEventListener("click", async () => {
  if (!currentTask) return;
  const answer = answerInput.value.trim();
  if (!answer) {
    feedback.textContent = "Enter an answer first.";
    feedback.classList.remove("hidden");
    return;
  }
  feedback.textContent = "Checking your answer…";
  feedback.classList.remove("hidden");
  try {
    const data = await callAI("check", { answer });
    feedback.textContent = data.feedback;
  } catch (error) {
    feedback.textContent = `Could not check the answer: ${error.message}`;
  }
});
answerInput.addEventListener("keydown", (event) => {
  if (event.key === "Enter") document.querySelector("#checkBtn").click();
});
